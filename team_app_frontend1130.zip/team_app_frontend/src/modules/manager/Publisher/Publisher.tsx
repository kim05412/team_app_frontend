const Publisher = () => {
  return <h1>Publisher</h1>;
};

export default Publisher;
