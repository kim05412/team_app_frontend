const Merchandiser = () => {
  return (
    <div>
      <h1>Merchandiser</h1>;
    </div>
  );
};

export default Merchandiser;
